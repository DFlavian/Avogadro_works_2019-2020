#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "funzioni.h"

int main() {
	char msg[80];
	int scelta;//variabile utile alla scelta dell'operazione da eseguire
	int msg_ins = 0;

	do {
		scelta = stampa_menu();
		switch(scelta) {
			case 1: {
				input_msg(msg);
				msg_ins = 1;
				break;
			}
			case 2: {
				if(msg_ins == 1) { //controlla se il messaggio � stato inserito
					codifica_decodifica(msg);
				} else {
					system("cls");
					printf("INSERIRE PRIMA UN MESSAGGIO DA CODIFICARE!!\n");
					system("pause");
				}
				break;
			}
		}
	} while(scelta != 3);
	return 0;
}
