#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <conio2.h>


int stampa_menu() { //Funzione che stampa il menu' per la codifica e che ritorna il valore della scelta
	int rig, sceltaf;
	do {
		system("cls");
		rig = 1;//Inizializzazione utile per mantenere il menu' sulle stesse righe qualora la scelta fosse errata

		gotoxy(31,rig);
		printf("CODIFICA/DECODIFICA MESSAGGIO");

		rig += 2;
		gotoxy(20,rig);
		printf("1. Inserire il messaggio");

		rig += 2;
		gotoxy(20,rig);
		printf("2. Messaggio codificato");


		rig += 2;
		gotoxy(20,rig);
		printf("3. Esci");

		rig += 2;
		gotoxy(20,rig);
		printf("Scelta --> .");
		gotoxy(31,rig);
		scanf("%d", &sceltaf);

	} while(sceltaf<=0 || sceltaf>3);
	return sceltaf;

}

void Stampa_vettore(char V[]) { //Procedura utile alla stampa di un vettore char
	int dim = strlen(V);
	for(int i = 0; i < dim; i++) {
		printf("%c", V[i]);
	}
	printf("\n");
}

void upper_string(char s[]) { //Procedura utile per l'ottenimento del messaggio SOLO IN MAIUSCOLO
	for (int i = 0; s[i]!='\0'; i++) {
		if(s[i] >= 'a' && s[i] <= 'z') {//Controllo per capire se il carattere e' una lettera minuscola
			s[i] = s[i] - 32;
		}
	}
}


void input_msg(char msgf[]) { //Procedura per ottenere il messaggio corretto da decodificare
	int ascii;
	int flag;

	do {
		system("cls");
		gotoxy(29,1);
		printf("INSERIRE UN MESSAGGIO");
		flag = 0;
		gotoxy(10,3);
		printf("NON mettere caratteri speciali");
		gotoxy(10,5);
		printf("--> ");
		gotoxy(14, 5);
		fflush(stdin);
		fflush(stdout);
		fgets(msgf, 80, stdin);
		upper_string(msgf);
		for (int i = 0; msgf[i] != '\0'; i++) { //loop fino alla fine della stringa

			ascii = msgf[i];//converte il carattere in un valore numerico rapresentante il suo valore in ASCII

			while((ascii < 65 || ascii > 90) && ascii != 0 && ascii != 32) { // Controlla se il valore e' una lettera

				if(ascii != 10) {
					flag = 1;
					break;
				}

				//Se non e' una lattera rimuovi il carattere e slitta tutte le lettere dopo di essa
				ascii = msgf[i+1];
			}
		}

	} while(flag == 1);

	gotoxy(10,5);
	printf("--> ");
}



void codifica_decodifica(char msgf[]) {
	int i, ascii;
	char cod[80];
	system("cls");
	for(i = 0; i < strlen(msgf) -1; i++) {

		ascii = msgf[i];//converte il carattere in un valore numerico rapresentante il suo valore in ASCII
		if(ascii != 32) { //Controlla se il carattere � uno spazio
			ascii = ascii - 65;//Tolgo 65 cosi' abbiamo valori da 0 a 25, rappresentanti le lettere dell'alfabeto in chiaro
			cod[i] = (25 - ascii) + 65;//Operazione utile a capire quale lettera del messaggio corrisponda al secondo alfabeto del codice atbash
		} else {
			cod[i] = 32;//inserisce uno spazio all'interno del messaggio
		}

	}
	cod[strlen(msgf)-1] = '\0'; //Setta il carattere per terminare la stringa
	gotoxy(29,1);
	printf("MESSAGGIO TRASFORMATO");
	gotoxy(10,3);
	printf("--> ");
	gotoxy(14, 3);
	printf("%s\n\n", cod);
	system("pause");
}
